import { prefetchProduct, prefetchProductIds } from "@/lib/hooks/prefetch";
import ProductDetailClient from "./ProductDetailClient";

interface ProductParam {
  id: string;
}

async function fetchProductIds(): Promise<string[]> {
  const ids = new Set<string>();
  const maxPages = 500;
  let page = 1;

  while (page <= maxPages) {
    try {
      const response = await fetch(
        `https://pharma-ecommerce-api.onrender.com/api/products/all-products-paginated?page=${page}&paginate=100`,
        { cache: "force-cache", next: { revalidate: 3600 } }
      );

      if (!response.ok) break;

      const data = await response.json();
      const list = Array.isArray(data)
        ? data
        : Array.isArray(data?.data)
          ? data.data
          : Array.isArray(data?.products)
            ? data.products
            : [];

      if (list.length === 0) break;

      for (const item of list) {
        if (item?.id !== undefined && item?.id !== null) {
          ids.add(String(item.id));
        }
      }

      page += 1;
    } catch {
      break;
    }
  }

  return Array.from(ids);
}

export async function generateStaticParams(): Promise<ProductParam[]> {
  const ids = await fetchProductIds();
  return ids.map((id) => ({ id }));
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<ProductParam>;
}) {
  const { id } = await params;
  
  // Prefetch product data on the server for hydration
  await prefetchProduct(id);

  return <ProductDetailClient id={id} />;
}
